package Model;

public class Category {
    public String CategoryName;

    public Category(String name) {
        this.CategoryName = name;
    }
}
