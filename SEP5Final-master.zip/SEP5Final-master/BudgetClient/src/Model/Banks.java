package Model;

public class Banks {

    public String NameOfBank;

    public Banks(String name) {
        this.NameOfBank = name;
    }
}